package com.example.wificardscanner

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var urlInput: EditText
    private lateinit var webView: WebView
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val accepted = AtomicBoolean(false)
    private var showingWeb = false

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startScanner() else status.text = "يلزم السماح للتطبيق باستخدام الكاميرا لمسح الكرت."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startScanner()
        else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun buildScreen() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18); setBackgroundColor(0xFFF7F8FA.toInt()) }
        val title = TextView(this).apply { text = "ماسح كروت الإنترنت"; textSize = 23f; gravity = Gravity.CENTER; setTextColor(0xFF17212B.toInt()) }
        root.addView(title, LinearLayout.LayoutParams(-1, 58))
        urlInput = EditText(this).apply { setSingleLine(true); textSize = 14f; setText("http://l.net/index.html"); hint = "رابط صفحة الدخول" }
        root.addView(urlInput, LinearLayout.LayoutParams(-1, 52))
        previewView = PreviewView(this).apply { implementationMode = PreviewView.ImplementationMode.COMPATIBLE }
        root.addView(previewView, LinearLayout.LayoutParams(-1, 0, 1f))
        status = TextView(this).apply { text = "وجّه الكاميرا نحو QR للكرت؛ ستتم القراءة تلقائياً"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(0xFF263238.toInt()); setPadding(8, 14, 8, 14) }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        val again = Button(this).apply { text = "مسح كرت آخر"; setOnClickListener { accepted.set(false); showingWeb = false; webView.visibility = View.GONE; previewView.visibility = View.VISIBLE; status.text = "وجّه الكاميرا نحو QR للكرت" } }
        root.addView(again, LinearLayout.LayoutParams(-1, 52))
        webView = WebView(this).apply {
            visibility = View.GONE
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    if (pendingUsername.isNotEmpty() && !injectedForCurrentPage) { injectedForCurrentPage = true; injectUsername(pendingUsername) }
                }
            }
        }
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun startScanner() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val scanner = BarcodeScanning.getClient()
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(cameraExecutor) { proxy ->
                if (accepted.get()) { proxy.close(); return@setAnalyzer }
                val media = proxy.image
                if (media == null) { proxy.close(); return@setAnalyzer }
                val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                scanner.process(image)
                    .addOnSuccessListener { codes ->
                        val raw = codes.firstOrNull { it.rawValue?.isNotBlank() == true }?.rawValue
                        if (raw != null && accepted.compareAndSet(false, true)) runOnUiThread { onQrRead(raw) }
                    }
                    .addOnCompleteListener { proxy.close() }
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) { status.text = "تعذر تشغيل الكاميرا: ${e.localizedMessage}" }
        }, ContextCompat.getMainExecutor(this))
    }

    private var pendingUsername = ""
    private var injectedForCurrentPage = false
    private fun onQrRead(raw: String) {
        val username = extractUsername(raw)
        if (username.isBlank() || username.length > 128) {
            accepted.set(false); status.text = "QR لا يحتوي اسم مستخدم صالحاً. حاول مسح الكرت مرة أخرى."; return
        }
        pendingUsername = username
        injectedForCurrentPage = false
        status.text = "تمت قراءة الكرت: $username — جارٍ فتح صفحة الدخول"
        val url = urlInput.text.toString().trim().ifBlank { "http://l.net/index.html" }
        previewView.visibility = View.GONE
        webView.visibility = View.VISIBLE
        showingWeb = true
        webView.loadUrl(url)
    }

    private fun injectUsername(username: String) {
        val safe = org.json.JSONObject.quote(username)
        val js = "(function(){var u=document.getElementById('myInput')||document.querySelector('input[name=username]');" +
                "var p=document.getElementById('password');if(!u)return 'NO_USERNAME_FIELD';u.value=$safe;" +
                "if(p)p.value='';u.dispatchEvent(new Event('input',{bubbles:true}));u.dispatchEvent(new Event('change',{bubbles:true}));" +
                "var b=document.getElementById('mySwitch');if(b){b.click();return 'LOGIN_CLICKED';}return 'USERNAME_FILLED';})()"
        webView.evaluateJavascript(js) { result ->
            status.text = when {
                result?.contains("LOGIN_CLICKED") == true -> "تمت تعبئة اسم المستخدم وطلب تسجيل الدخول."
                result?.contains("NO_USERNAME_FIELD") == true -> "فتحت الصفحة لكن لم أجد خانة اسم المستخدم."
                else -> "تمت تعبئة اسم المستخدم. إذا لم يبدأ الدخول اضغط زر دخول الإنترنت."
            }
        }
    }

    private fun extractUsername(raw: String): String {
        var value = raw.trim()
        try {
            if (value.startsWith("http://", true) || value.startsWith("https://", true)) {
                val uri = android.net.Uri.parse(value)
                value = uri.getQueryParameter("username") ?: uri.getQueryParameter("user") ?: uri.lastPathSegment ?: value
            }
        } catch (_: Exception) { }
        return value.removePrefix("username:").removePrefix("user:").trim()
    }

    override fun onDestroy() { super.onDestroy(); cameraExecutor.shutdown() }
}
