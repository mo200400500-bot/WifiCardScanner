# بناء APK من الهاتف فقط

هذا المشروع لا يحتوي APK جاهزاً. يمكن بناؤه على خوادم GitHub Actions من الهاتف دون Android Studio.

## الخطوات
1. افتح https://github.com من متصفح الهاتف وسجّل الدخول أو أنشئ حساباً.
2. أنشئ مستودعاً جديداً (New repository)، وسمّه WifiCardScanner. يمكن اختيار Private.
3. افتح المستودع، اختر Add file ثم Upload files.
4. فك ضغط WifiCardScanner_Source_MOBILE_BUILD.zip على الهاتف أولاً، ثم ارفع **محتويات مجلد WifiCardScanner** إلى جذر المستودع. يجب أن ترى build.gradle وsettings.gradle ومجلد app ومجلد .github.
   - إذا لم يظهر مجلد .github في منتقي الملفات، أنشئ المسار والملف من Add file > Create new file واكتب المسار `.github/workflows/android-apk.yml` ثم انسخ محتوى الملف من النسخة المفكوكة.
5. اضغط Commit changes.
6. افتح تبويب Actions في المستودع، واختر Build Android APK، ثم Run workflow.
7. انتظر حتى تنتهي المهمة بعلامة خضراء. افتح نتيجة التشغيل، وانزل إلى Artifacts، واضغط WifiCardScanner-debug-apk لتنزيل ZIP.
8. فك ضغط ملف Artifact على الهاتف. ستجد app-debug.apk. اضغطه وثبّته. قد يطلب Android السماح بالتثبيت من هذا المصدر.

ملاحظات:
- أول بناء قد يستغرق عدة دقائق ويتطلب اتصال إنترنت مستقراً.
- ملف APK الناتج نسخة Debug للتجربة، وليس إصداراً نهائياً موقعاً للنشر.
- نجاح البناء لا يعني أن التطبيق اختُبر على جهازك أو أن تسجيل الدخول في Tera مضمون؛ يجب اختبار الكاميرا وحقول صفحة الدخول بعد التثبيت.
